

#ifndef LOLINPINS_h
#define LOLINPINS_h
//PE4
#define _LOLIN_RX_  21
#define _LOLIN_RX_MASK_ 5 
#define _LOLIN_TX_  20 //PE5
#define _LOLIN_RST_ 22//PE1


#endif
